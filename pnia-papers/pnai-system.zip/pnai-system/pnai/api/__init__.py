"""HTTP API + live dashboard."""
